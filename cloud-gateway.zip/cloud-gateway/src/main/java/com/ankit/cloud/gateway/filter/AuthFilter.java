package com.ankit.cloud.gateway.filter;
import com.ankit.cloud.gateway.config.RouteValidator;
import com.ankit.cloud.gateway.dto.ApiResponse;
import com.ankit.cloud.gateway.dto.AuthRequest;
import com.ankit.cloud.gateway.dto.ResponseDTO;
import com.ankit.cloud.gateway.dto.UserLoginDTO;
import com.ankit.cloud.gateway.entity.UserLogin;
import com.ankit.cloud.gateway.repository.UserLoginRepository;
import com.ankit.cloud.gateway.service.AuthService;
import com.ankit.cloud.gateway.service.JWTService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.ResolvableType;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class AuthFilter implements GlobalFilter  {

    private static Logger logger = LoggerFactory.getLogger(AuthFilter.class);

    @Autowired
    private RouteValidator validator;

    //    @Autowired
//    private RestTemplate template;
    @Autowired
    private JWTService jwtUtil;

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private AuthService authService;



    /*public AuthFilter() {
        super(Config.class);
    }*/

    @Override
    public Mono<Void> filter(ServerWebExchange exchange,
                             GatewayFilterChain chain) {
        System.out.println("IN FILTER");
            logger.info("Inside RETURN");
            logger.info("Inside : "+validator.isSecured.test(exchange.getRequest()));
            logger.info(exchange.getRequest().getPath().toString());
            if (validator.isSecured.test(exchange.getRequest())) {
                //header contains token or not
                logger.info("Inside IF");
                //final Map<String,String> kv = new HashMap<>();
                if (exchange.getRequest().getPath().toString().contains("/socketservice")) {
                    /*return Mono.just(exchange.getRequest().getQueryParams())
                            .filter(map -> map.containsKey("token"))
                            .flatMap(
                                    tokenMap -> Mono.just(tokenMap.get("token")).
                                            flatMap(
                                                    tokenList -> {
                                                            if(tokenList != null && !tokenList.isEmpty()){
                                                                return Mono.just(tokenList.get(0)).flatMap(
                                                                        token -> authService.validateToken(token).flatMap(
                                                                                bool -> {
                                                                                    if(bool.booleanValue()){
                                                                                        return chain.filter(exchange);
                                                                                    }else{
                                                                                        return authService.getUnAuthResponse(exchange);
                                                                                    }
                                                                                }
                                                                        )
                                                                );
                                                            }
                                                            else{
                                                                return authService.getUnAuthResponse(exchange);
                                                            }
                                                    }
                                            )
                            );*/

                    MultiValueMap<String, String> kv = exchange.getRequest().getQueryParams();
                    if(kv != null && !kv.isEmpty()){
                        List<String> tokenList = kv.get("token");
                        if(tokenList != null){
                            String token = tokenList.get(0);
                            if(token != null){
                                try {
                                    return authService.validateToken(token).flatMap(
                                            bool -> {
                                                if(bool.booleanValue()){
                                                    return chain.filter(exchange);
                                                }else{
                                                    return authService.getUnAuthResponse(exchange);
                                                }
                                            }
                                    );
                                    //return chain.filter(exchange);
                                } catch (Exception e) {
                                    authService.getUnAuthResponse(exchange);
                                }
                            }else{
                                return authService.getUnAuthResponse(exchange);
                            }
                        }
                        else{
                            return authService.getUnAuthResponse(exchange);
                        }
                    }
                    else{
                        return authService.getUnAuthResponse(exchange);
                    }
                }
                else{
                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
                    System.out.println("invalid access...!");
                    ServerHttpResponse response = exchange.getResponse();
                    response.setStatusCode(HttpStatus.UNAUTHORIZED);
                    response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
                    System.out.println("UN-AUTHORIZED REQUEST");
                    byte[] bytes = "{\"Message\" : \"Full Authentication is Required to access this resource\",\n\"status\" : \"401\",\n\"responseData\" : \"UN-AUTHORIZED REQUEST\"}".getBytes(StandardCharsets.UTF_8);
                    DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
                    return response.writeWith(Flux.just(buffer));
                }

                String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
                if (authHeader != null && authHeader.startsWith("Bearer ")) {
                    authHeader = authHeader.substring(7);
                }
                try {
//                    //REST call to AUTH service
//                    template.getForObject("http://IDENTITY-SERVICE//validate?token" + authHeader, String.class);
                    jwtUtil.validateToken(authHeader);

                } catch (Exception e) {
                    System.out.println("invalid access...!");
                    ServerHttpResponse response = exchange.getResponse();
                    response.setStatusCode(HttpStatus.UNAUTHORIZED);
                    response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
                    System.out.println("UN-AUTHORIZED REQUEST");
                    byte[] bytes = "{\"Message\" : \"Full Authentication is Required to access this resource\",\n\"status\" : \"401\",\n\"responseData\" : \"UN-AUTHORIZED REQUEST\"}".getBytes(StandardCharsets.UTF_8);
                    DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
                    return response.writeWith(Flux.just(buffer));
                }
                return chain.filter(exchange);
            }
                return chain.filter(exchange);
            }
            else{
                return chain.filter(exchange);
            }
    }

    /*public static class Config {

    }*/
}