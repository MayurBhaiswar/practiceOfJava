/*

package com.ankit.cloud.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

public class AuthPostFilter implements GlobalFilter, Ordered {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        return chain.filter(exchange).then(Mono.fromRunnable(()->{
            System.out.println("Inside Post filter");
            var response = exchange.getResponse();
            response.setRawStatusCode(201);
            exchange.mutate().response(response).build();
        }));
    }

    @Override
    public int getOrder() {
        return 0;
    }
}*/
