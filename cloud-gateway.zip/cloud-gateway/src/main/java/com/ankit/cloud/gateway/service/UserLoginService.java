package com.ankit.cloud.gateway.service;

import com.ankit.cloud.gateway.entity.UserLogin;
import com.ankit.cloud.gateway.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Component
public class UserLoginService implements ReactiveUserDetailsService {

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Override
    public Mono<UserDetails> findByUsername(String emailId) {
        System.out.println("Inside Find User");
        return userLoginRepository.findUserLoginByEmailId(emailId).cast(UserDetails.class);
/*
                .doOnNext(user -> System.out.println(user))
                .switchIfEmpty(Mono.error(new RuntimeException()))
                .map(u -> u);*/
    }

    public Flux<UserLogin> findAllUsers(){
        return userLoginRepository.findAll();
    }

    public void saveUser(UserLogin userLogin){
        System.out.println("Inside Save User Service 1");
        System.out.println("Password: "+userLogin.getPassword());

         userLoginRepository.save(userLogin).subscribe();
    }
}
