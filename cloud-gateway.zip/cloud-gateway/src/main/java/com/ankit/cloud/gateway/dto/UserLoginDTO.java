package com.ankit.cloud.gateway.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.HashSet;
import java.util.Set;

/**
 * @author arti.patel
 */
@Builder
@AllArgsConstructor
public class UserLoginDTO {
    private int userId;
    private String loginId;
    private String password;
    private String userName;
    private String mobileNo;
    private Integer tblTimeZone;
    private String alternateLoginId;
    private Integer tblClient;
    private int failedLoginAttempt;
    //private String hintAnswer;
    private int isEmailVerified;
    private int isFirstLogin;
    //private Date passwordUpdatedOn;
    //private Integer tblHintQuestion;
    private String verificationCode;
    private   String ipAddress;
    //private   int sSOUserExist;
    //private   int isMigrated ;
    //private   int isMobileNoVerified;
    //private   Date generatedOtpDate;
    //not need
   // private int createdBy;
   // private Date createdOn;

    private Set<UserDetailDTO> userDetailDTOS = new HashSet<>();

    public Set<UserDetailDTO> getUserDetailDTOS() {
        return userDetailDTOS;
    }

    public void setUserDetailDTOS(Set<UserDetailDTO> userDetailDTOS) {
        this.userDetailDTOS = userDetailDTOS;
    }

    public UserLoginDTO() {
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public Integer getTblTimeZone() {
        return tblTimeZone;
    }

    public void setTblTimeZone(Integer tblTimeZone) {
        this.tblTimeZone = tblTimeZone;
    }

    public String getAlternateLoginId() {
        return alternateLoginId;
    }

    public void setAlternateLoginId(String alternateLoginId) {
        this.alternateLoginId = alternateLoginId;
    }

    public Integer getTblClient() {
        return tblClient;
    }

    public void setTblClient(Integer tblClient) {
        this.tblClient = tblClient;
    }

    public int getFailedLoginAttempt() {
        return failedLoginAttempt;
    }

    public void setFailedLoginAttempt(int failedLoginAttempt) {
        this.failedLoginAttempt = failedLoginAttempt;
    }

//    public String getHintAnswer() {
//        return hintAnswer;
//    }
//
//    public void setHintAnswer(String hintAnswer) {
//        this.hintAnswer = hintAnswer;
//    }

    public int getIsEmailVerified() {
        return isEmailVerified;
    }

    public void setIsEmailVerified(int isEmailVerified) {
        this.isEmailVerified = isEmailVerified;
    }

    public int getIsFirstLogin() {
        return isFirstLogin;
    }

    public void setIsFirstLogin(int isFirstLogin) {
        this.isFirstLogin = isFirstLogin;
    }

//    public Date getPasswordUpdatedOn() {
//        return passwordUpdatedOn;
//    }
//
//    public void setPasswordUpdatedOn(Date passwordUpdatedOn) {
//        this.passwordUpdatedOn = passwordUpdatedOn;
//    }
//
//    public Integer getTblHintQuestion() {
//        return tblHintQuestion;
//    }
//
//    public void setTblHintQuestion(Integer tblHintQuestion) {
//        this.tblHintQuestion = tblHintQuestion;
//    }

    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }



//    public int getIsMigrated() {
//        return isMigrated;
//    }
//
//    public void setIsMigrated(int isMigrated) {
//        this.isMigrated = isMigrated;
//    }
//
//    public int getIsMobileNoVerified() {
//        return isMobileNoVerified;
//    }
//
//    public void setIsMobileNoVerified(int isMobileNoVerified) {
//        this.isMobileNoVerified = isMobileNoVerified;
//    }
//
//    public Date getGeneratedOtpDate() {
//        return generatedOtpDate;
//    }
//
//    public void setGeneratedOtpDate(Date generatedOtpDate) {
//        this.generatedOtpDate = generatedOtpDate;
//    }
}
