package com.ankit.cloud.gateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UserDetailsRepositoryReactiveAuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.server.SecurityWebFilterChain;

@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {
    @Autowired
    private ReactiveUserDetailsService reactiveUserDetailsService;

    /*@Bean
    public ReactiveUserDetailsService userDetailsService(){
        return reactiveUserDetailsService;
    }*/

    @Bean
    public SecurityWebFilterChain filterChain(ServerHttpSecurity http) {
        return http
                .csrf().disable()
                .authorizeExchange().anyExchange().permitAll()
                .and().
                authenticationManager(reactiveAuthenticationManager())
                .httpBasic().and()
                .build();
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    ReactiveAuthenticationManager reactiveAuthenticationManager(){
        UserDetailsRepositoryReactiveAuthenticationManager ur = new UserDetailsRepositoryReactiveAuthenticationManager(reactiveUserDetailsService);
                ur.setPasswordEncoder(passwordEncoder());
        return ur;
    }

   /* @Bean
    public MapReactiveUserDetailsService getInMemoryUserDetails() {
        *//*UserDetails admin = User.withDefaultPasswordEncoder().username("admin1").password("password")
                .roles("ADMIN")
                .build();*//*
        return new MapReactiveUserDetailsService(admin);
    }*/
}
