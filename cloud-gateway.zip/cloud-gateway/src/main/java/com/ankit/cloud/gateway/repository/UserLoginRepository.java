package com.ankit.cloud.gateway.repository;

import com.ankit.cloud.gateway.entity.UserLogin;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository

public interface UserLoginRepository extends ReactiveCrudRepository<UserLogin,String> {
    @Query("{loginId:'?0'}")
    public Mono<UserLogin> findUserLoginByEmailId(String loginId);
}
