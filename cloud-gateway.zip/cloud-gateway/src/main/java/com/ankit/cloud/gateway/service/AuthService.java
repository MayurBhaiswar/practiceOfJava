package com.ankit.cloud.gateway.service;
import com.ankit.cloud.gateway.entity.UserLogin;
import com.ankit.cloud.gateway.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;

@Service
public class AuthService {

    /*@Autowired
    private UserLoginRepository userLoginRepository;*/
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JWTService jwtService;

    /*public String saveUser(UserLogin user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userLoginRepository.save(user).subscribe();
        return "user added to the system";
    }*/

    public String generateToken(String username) {
        return jwtService.generateToken(username);
    }

    /*public void validateToken(String token) {
        jwtService.validateToken(token);
    }*/

    public Mono<Boolean> validateToken(String token) {
        System.out.println("Inside Validate token service 1");
        return jwtService.validateToken(token);
    }

    public Mono<Void> getUnAuthResponse(ServerWebExchange exchange){
        System.out.println("invalid socket access...!");
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        System.out.println("UN-AUTHORIZED REQUEST");
        byte[] bytes = "{\"Message\" : \"Full Authentication is Required to access this resource\",\n\"status\" : \"401\",\n\"responseData\" : \"UN-AUTHORIZED REQUEST\"}".getBytes(StandardCharsets.UTF_8);
        DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
        return response.writeWith(Flux.just(buffer));
    }

}