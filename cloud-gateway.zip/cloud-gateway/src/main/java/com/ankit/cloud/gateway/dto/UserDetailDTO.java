package com.ankit.cloud.gateway.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;

/**
 * @author arti.patel
 */
@Builder
@AllArgsConstructor
public class UserDetailDTO {

    private String deptName;
    private String designation;
    private String companyName;
    private String loginId;
    private Integer clientId;
    //TblUserLogin
    private Integer userId;
    private int userDetailId;
    private String userName;

    //not need
    //private int createdBy;
    //private Date createdOn;

    public UserDetailDTO() {
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public int getUserDetailId() {
        return userDetailId;
    }

    public void setUserDetailId(int userDetailId) {
        this.userDetailId = userDetailId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
