package com.ankit.cloud.gateway.controller;

import com.ankit.cloud.gateway.dto.ApiResponse;
import com.ankit.cloud.gateway.dto.AuthRequest;
import com.ankit.cloud.gateway.dto.AuthResponse;
import com.ankit.cloud.gateway.dto.ResponseDTO;
import com.ankit.cloud.gateway.entity.UserLogin;
import com.ankit.cloud.gateway.repository.UserLoginRepository;
import com.ankit.cloud.gateway.service.AuthService;
import com.ankit.cloud.gateway.service.UserLoginService;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.support.NotFoundException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ReactiveAuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

import java.time.Duration;
import java.util.function.Predicate;

import static org.springframework.http.MediaType.APPLICATION_JSON;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService service;

    @Autowired
    private UserLoginRepository userLoginRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ReactiveAuthenticationManager authenticationManager;

    @Autowired
    private UserLoginService userLoginService;

    /*@PostMapping("/register")
    public Mono<String> addNewUser(@RequestBody UserLogin user) {
        user.setPassword(passwordEncoder.encode( user.getPassword()));
        userLoginService.saveUser(user);
        return Mono.just("User Saved");
    }*/

    @PostMapping("register")
    public Mono<ResponseEntity<ResponseDTO>> saveUser(@RequestBody Mono<UserLogin> userLogin){
        return userLogin.map(
                ul -> {
                    ul.setFailedLoginAttempt(0);
                    ul.setPassword(passwordEncoder.encode(ul.getPassword()));
                return ul;
                }
        ).flatMap(
            ul -> userLoginRepository.findUserLoginByEmailId(ul.getLoginId())
                .flatMap(u -> Mono.just(ResponseEntity.badRequest().body(new ResponseDTO("User already exists","Bad Request"))))
                  .switchIfEmpty(
                    userLoginRepository.save(ul)
                     .flatMap(ull -> Mono.just(ResponseEntity.ok(new ResponseDTO("User saved successfully","success"))))
                    )
        );
    }

    @RequestMapping(method = RequestMethod.GET,path = "/getallusers", produces = MediaType.APPLICATION_STREAM_JSON_VALUE)
    public Flux<UserLogin> getAllUser() {
        System.out.println("Inside Get All Users Method");
        return userLoginRepository.findAll();
        //return users.doOnNext(u -> System.out.println(u.getUsername()));
    }

    /*@PostMapping("/token")
    public Mono<ResponseEntity<AuthResponse>> getToken(@RequestBody AuthRequest authRequest) {
        return authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword()))
                .map(au -> au.isAuthenticated())
                  .map(
                    isTrue ->  {
                        if(isTrue.booleanValue()) {
                            System.out.println("TRUE CALLED");
                            return ResponseEntity.ok(new AuthResponse(service.generateToken(authRequest.getUserName())));
                    }
              else{
                            return ResponseEntity.ok(new AuthResponse("Bad Credentials"));
              }
          }
        );

    }*/

    @PostMapping("/token")
    public Mono<Object> getToken(@RequestBody Mono<AuthRequest> authRequest){
        return authRequest.flatMap(
                au -> userLoginRepository.findUserLoginByEmailId(au.getLoginId())
                        .flatMap(
                                ul -> Mono.just(passwordEncoder.matches(au.getPassword(),ul.getPassword()))
                                        .flatMap(b -> {
                                            if(b.booleanValue()){
                                                if(ul.getFailedLoginAttempt() >= 3){
                                                    ApiResponse<String> userLocked = new ApiResponse<String>();
                                                    userLocked.setMessage("User is Locked due to Unsuccessive Login attempts");
                                                    userLocked.setResponseData("User is Locked due to Unsuccessive Login attempts");
                                                    userLocked.setStatusCode(400);
                                                    return Mono.just(userLocked);
                                                }
                                                else {
                                                    ApiResponse<AuthResponse> userValid = new ApiResponse<AuthResponse>();
                                                    userValid.setMessage("SUCCESS");
                                                    userValid.setResponseData(new AuthResponse(service.generateToken(au.getLoginId()),ul.getUserId(),ul.getUsertypeId()));
                                                    //userValid.setResponseData(service.generateToken(au.getLoginId())+"!@#!"+ul.getUserId());
                                                    userValid.setStatusCode(200);
                                                    return Mono.just(userValid);
                                                }
                                            }else{
                                                if(ul.getFailedLoginAttempt() <= 3) {
                                                    ul.setFailedLoginAttempt(ul.getFailedLoginAttempt() + 1);
                                                    return userLoginRepository.save(ul).flatMap(u ->
                                                            Mono.just(new ApiResponse<String>("Bad Credentials",400,"Bad Credentials"))
                                                    );

                                                }
                                                else {
                                                    return Mono.just(new ApiResponse<String>("User is Locked due to Unsuccessive Login attempts",400,"User is Locked due to Unsuccessive Login attempts"));
                                                }
                                            }
                                        })


                                        //? Mono.just(ResponseEntity.ok(new AuthResponse(service.generateToken(au.getUserName())))) :
                                        //Mono.just(ResponseEntity.badRequest().body(new AuthResponse("Bad Credentials")))
                        )
                        .switchIfEmpty(
                                Mono.just(new ApiResponse<String>("Bad Credentials",400,"Bad Credentials"))
                        )
                        .onErrorReturn(
                                new ApiResponse<String>("Exception Occured",500,"Exception Occured")
                        )

        );
    }

    @PostMapping("/validate")
    public Mono<ResponseEntity<ResponseDTO>> validateToken(@RequestParam("token") String token) {
        System.out.println("Inside Validate token controller");
        return service.validateToken(token)
                .flatMap(a -> {
                    if(a.booleanValue()){
                            return Mono.just(ResponseEntity.ok(new ResponseDTO("Token is valid", "OK")));
                    }
                    else{
                        return Mono.just(ResponseEntity.badRequest().body(new ResponseDTO("Token is not valid","BAD REQUEST")));
                    }
                        }
                );
        //return Mono.just("Token is valid");
    }

    @GetMapping("/hello")
    public Mono<String> hello() {
        return Mono.just("Hello Works");
    }


    @PostMapping("/tokentestafterdemo")
    public String getToken(@RequestParam("loginId") String loginId){
        String token = service.generateToken(loginId);
        return token;
    }

    @PostMapping("/registertogateway")
    public Mono<ResponseEntity<ResponseDTO>> saveUserFromCommon(@RequestBody Mono<UserLogin> userLogin){
        return userLogin.map(
                ul -> {
                    ul.setFailedLoginAttempt(0);
                    ul.setPassword(passwordEncoder.encode(ul.getPassword()));
                    return ul;
                }
        ).flatMap(
                ul -> userLoginRepository.findUserLoginByEmailId(ul.getLoginId())
                        .flatMap(u -> Mono.just(ResponseEntity.badRequest().body(new ResponseDTO("User already exists","Bad Request"))))
                        .switchIfEmpty(
                                userLoginRepository.save(ul)
                                        .flatMap(ull -> Mono.just(ResponseEntity.ok(new ResponseDTO("User saved successfully","success"))))
                        )
        );
    }
}
