package com.ankit.cloud.gateway;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackMethodController {
    @GetMapping("/userserviefallback")
    public String userServiceFallBackMethod(){
        return "User Service is taking longer than Expected"+
                "Please Try again Later";
    }

    @GetMapping("/departmentserviefallback")
    public String departmentServiceFallBackMethod(){
        return "Department Service is taking longer than Expected"+
                "Please Try again Later";
    }
}
